Storage API
* window.localStorage (object)
* Key/Value store
* Both Key & Value should be strings
* API
    - setItem(key, value)
    - removeItem(key)
    - getItem(key) // => value
    - clear()
    - key(index) //=> key
    - length
    

    